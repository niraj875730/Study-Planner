package com.example.study_planner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudyPlannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
